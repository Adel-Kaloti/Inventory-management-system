# Install required packages if not already installed
# install.packages(c("readxl", "dplyr", "ggplot2", "lubridate", "Metrics", "ranger"))

library(readxl)
library(dplyr)
library(ggplot2)
library(lubridate)
library(Metrics)
library(ranger)
library(randomForest)

# 1. Load data
train_data <- read_excel("training_data.xlsx")
test_data  <- read_excel("test_data.xlsx")

train_data$id <- as.factor(train_data$id)
test_data$id <- as.factor(test_data$id)


# 2. Preprocessing – extract date parts and is_weekend
train_data <- train_data %>%
  mutate(date = as.Date(date),
         day = day(date),
         month = month(date),
         year = year(date),
         weekday = wday(date, week_start = 1),  # Monday = 1, Sunday = 7
         is_weekend = ifelse(weekday %in% c(5,6), 1, 0))  # Friday/Saturday

test_data <- test_data %>%
  mutate(date = as.Date(date),
         day = day(date),
         month = month(date),
         year = year(date),
         weekday = wday(date, week_start = 1),
         is_weekend = ifelse(weekday %in% c(5,6), 1, 0))

# 3. Build the Random Forest model with is_weekend
rf_model <- randomForest(demand ~id + day + month + year + weekday + is_weekend, 
                         data = train_data, 
                         ntree = 200)

# 4. Predict demand on May test data
test_data$predicted_demand <- predict(rf_model, newdata = test_data)

# 5. Combine results
result <- test_data %>%
  select(id, date,is_weekend, predicted_demand, actual_demand = demand)

# 6. Evaluation
mae_val <- mae(result$actual_demand, result$predicted_demand)
rmse_val <- rmse(result$actual_demand, result$predicted_demand)
r2_val <- cor(result$actual_demand, result$predicted_demand)^2

cat("Model Evaluation Metrics:\n")
cat(paste("MAE  (Mean Absolute Error):", round(mae_val, 2), "\n"))
cat(paste("RMSE (Root Mean Squared Error):", round(rmse_val, 2), "\n"))
cat(paste("R²   (Coefficient of Determination):", round(r2_val, 4), "\n"))

# 7. Plot comparison
ggplot(result, aes(x = predicted_demand, y = actual_demand)) +
  geom_point(color = "blue", alpha = 0.7) +
  geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed") +
  labs(title = "Predicted vs. Actual Demand (May)",
       x = "Predicted Demand",
       y = "Actual Demand")

importance_df <- data.frame(
  Variable = rownames(importance_values),
  Importance = importance_values[, "IncNodePurity"]
)

# סידור בסדר יורד
importance_df <- importance_df[order(importance_df$Importance, decreasing = TRUE), ]

# גרף
library(ggplot2)
ggplot(importance_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "darkgreen") +
  coord_flip() +
  labs(title = "חשיבות משתנים לפי IncNodePurity",
       x = "משתנה",
       y = "חשיבות") +
  theme_minimal()


################################################################################

# 1. Create date range
future_dates <- seq(as.Date("2025-06-01"), as.Date("2025-07-12"), by = "day")

# 2. Get all product IDs from training set
product_ids <- unique(train_data$id)

# 3. Create full prediction grid: all IDs × dates
prediction_data <- expand.grid(
  id = product_ids,
  date = future_dates,
  stringsAsFactors = FALSE
)

# 4. Add features
prediction_data <- prediction_data %>%
  mutate(id = as.factor(id),
         day = day(date),
         month = as.factor(month(date)),
         year = year(date),
         weekday = wday(date, week_start = 1),
         is_weekend = ifelse(weekday %in% c(5, 6), 1, 0))

# 5. Ensure factor levels match training data
prediction_data$id <- factor(prediction_data$id, levels = levels(train_data$id))

# 6. Predict using trained model
prediction_data$predicted_demand <- predict(rf_model, newdata = prediction_data)

# 7. View or export results
head(prediction_data)
write.csv(prediction_data, "predicted_demand_June_July_2025.csv", row.names = FALSE)


































