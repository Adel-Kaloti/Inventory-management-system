install.packages("readxl")
install.packages("openxlsx")

library(readxl)
library(openxlsx)

product_ids <- as.character(read_excel("ids5.xlsx")$id)
start_date <- as.Date("2025-01-01")
end_date   <- Sys.Date()
dates      <- seq.Date(from = start_date, to = end_date, by = "day")

demand_data <- expand.grid(
  id   = product_ids,
  date = dates,
  stringsAsFactors = FALSE
)

demand_data$date <- format(demand_data$date, "%Y-%m-%d")

set.seed(42)
demand_data$demand <- sample(0:1, nrow(demand_data), replace = TRUE)

unique_dates <- unique(demand_data$date)
high_dates   <- sample(unique_dates, size = floor(length(unique_dates) * 0.1))
mask         <- demand_data$date %in% high_dates
demand_data$demand[mask] <- ceiling(demand_data$demand[mask] * 2)
write.csv(demand_data, "daily_demand5.csv", row.names = FALSE)

head(demand_data)
